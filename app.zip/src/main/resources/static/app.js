const etat = {
    session: null,
    comptes: [],
    categories: [],
    sources: [],
    devises: [],
    compteOuvert: null
};

const $ = (selecteur) => document.querySelector(selecteur);

async function api(methode, url, corps) {
    const options = { method: methode, headers: {} };
    if (corps !== undefined) {
        options.headers['Content-Type'] = 'application/json';
        options.body = JSON.stringify(corps);
    }
    const reponse = await fetch(url, options);
    const texte = await reponse.text();
    const donnees = texte ? JSON.parse(texte) : null;
    if (!reponse.ok) {
        if (reponse.status === 401 && etat.session) {
            etat.session = null;
            afficherConnexion();
        }
        throw new Error(donnees && donnees.erreur ? donnees.erreur : 'Erreur ' + reponse.status);
    }
    return donnees;
}

function afficherMessage(texte, type) {
    const zone = $('#message');
    zone.textContent = texte;
    zone.className = type;
    zone.hidden = false;
    clearTimeout(afficherMessage.minuteur);
    afficherMessage.minuteur = setTimeout(() => { zone.hidden = true; }, 6000);
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function executer(action, messageSucces) {
    try {
        const resultat = await action();
        if (messageSucces) {
            afficherMessage(messageSucces, 'succes');
        }
        return resultat;
    } catch (e) {
        afficherMessage(e.message, 'erreur');
        return undefined;
    }
}

function montant(valeur, code) {
    const nombre = Number(valeur);
    try {
        return nombre.toLocaleString('fr-FR', { style: 'currency', currency: code || 'EUR' });
    } catch (e) {
        return nombre.toFixed(2) + ' ' + (code || '');
    }
}

function dateFr(valeur) {
    if (!valeur) {
        return '';
    }
    const [a, m, j] = String(valeur).substring(0, 10).split('-');
    return j + '/' + m + '/' + a;
}

function moisFr(valeur) {
    const [a, m] = String(valeur).split('-');
    const date = new Date(Number(a), Number(m) - 1, 1);
    const texte = date.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
    return texte.charAt(0).toUpperCase() + texte.slice(1);
}

function codeDevise(idDevise) {
    const devise = etat.devises.find((d) => d.idDevise === idDevise);
    return devise ? devise.code : '';
}

function cellule(texte, classe) {
    const td = document.createElement('td');
    td.textContent = texte;
    if (classe) {
        td.className = classe;
    }
    return td;
}

function bouton(texte, classe, action) {
    const b = document.createElement('button');
    b.type = 'button';
    b.textContent = texte;
    b.className = classe;
    b.addEventListener('click', action);
    return b;
}

function ligneVide(tbody, nbColonnes, texte) {
    const tr = document.createElement('tr');
    const td = cellule(texte);
    td.colSpan = nbColonnes;
    tr.appendChild(td);
    tbody.appendChild(tr);
}

function remplirSelect(select, elements, valeur, libelle) {
    select.replaceChildren();
    for (const element of elements) {
        const option = document.createElement('option');
        option.value = valeur(element);
        option.textContent = libelle(element);
        select.appendChild(option);
    }
}

function activerOnglets(section) {
    const boutons = section.querySelectorAll('.onglets button');
    const onglets = section.querySelectorAll('.onglet');
    boutons.forEach((b) => {
        b.addEventListener('click', () => {
            boutons.forEach((x) => x.classList.toggle('actif', x === b));
            onglets.forEach((o) => { o.hidden = o.id !== b.dataset.onglet; });
            const chargement = chargements[b.dataset.onglet];
            if (chargement) {
                chargement();
            }
        });
    });
}

function ouvrirPremierOnglet(section) {
    section.querySelector('.onglets button').click();
}

function afficherConnexion() {
    $('#zone-utilisateur').hidden = true;
    $('#ecran-utilisateur').hidden = true;
    $('#ecran-admin').hidden = true;
    $('#ecran-connexion').hidden = false;
}

async function afficherApplication() {
    $('#ecran-connexion').hidden = true;
    $('#zone-utilisateur').hidden = false;
    $('#nom-utilisateur').textContent = etat.session.pseudo + (etat.session.role === 'ADMIN' ? ' (administrateur)' : '');

    etat.categories = await api('GET', '/api/categories');

    if (etat.session.role === 'ADMIN') {
        $('#ecran-utilisateur').hidden = true;
        $('#ecran-admin').hidden = false;
        ouvrirPremierOnglet($('#ecran-admin'));
    } else {
        etat.sources = await api('GET', '/api/sources');
        etat.devises = await api('GET', '/api/devises');
        remplirSelect($('#saisie-source'), etat.sources, (s) => s.idSource, (s) => s.nom);
        remplirSelect($('#compte-devise'), etat.devises, (d) => d.idDevise, (d) => d.code);
        $('#ecran-admin').hidden = true;
        $('#ecran-utilisateur').hidden = false;
        ouvrirPremierOnglet($('#ecran-utilisateur'));
    }
}

async function chargerComptes() {
    etat.comptes = await api('GET', '/api/comptes');
    const tbody = $('#table-comptes tbody');
    tbody.replaceChildren();

    if (etat.comptes.length === 0) {
        ligneVide(tbody, 4, 'Aucun compte pour le moment.');
    }

    for (const ligne of etat.comptes) {
        const c = ligne.compte;
        const tr = document.createElement('tr');
        if (etat.compteOuvert === c.idCompte) {
            tr.classList.add('selectionne');
        }
        tr.appendChild(cellule(c.nom));
        tr.appendChild(cellule(c.type));
        tr.appendChild(cellule(montant(ligne.solde, codeDevise(c.idDevise)), 'nombre'));
        const actions = document.createElement('td');
        actions.className = 'nombre';
        actions.appendChild(bouton('Opérations', 'outline', () => chargerTransactions(c.idCompte)));
        actions.append(' ');
        actions.appendChild(bouton('Supprimer', 'secondary outline', () => supprimerCompte(c)));
        tr.appendChild(actions);
        tbody.appendChild(tr);
    }

    remplirSelect($('#saisie-compte'), etat.comptes, (l) => l.compte.idCompte,
        (l) => l.compte.nom + ' (' + montant(l.solde, codeDevise(l.compte.idDevise)) + ')');

    if (etat.compteOuvert !== null && etat.comptes.some((l) => l.compte.idCompte === etat.compteOuvert)) {
        await chargerTransactions(etat.compteOuvert);
    } else {
        etat.compteOuvert = null;
        $('#bloc-transactions').hidden = true;
    }
}

async function chargerTransactions(idCompte) {
    const transactions = await executer(() => api('GET', '/api/comptes/' + idCompte + '/transactions'));
    if (!transactions) {
        return;
    }
    etat.compteOuvert = idCompte;
    const ligne = etat.comptes.find((l) => l.compte.idCompte === idCompte);
    const code = codeDevise(ligne.compte.idDevise);

    document.querySelectorAll('#table-comptes tbody tr').forEach((tr, i) => {
        tr.classList.toggle('selectionne', etat.comptes[i] && etat.comptes[i].compte.idCompte === idCompte);
    });

    $('#titre-transactions').textContent = 'Opérations du compte « ' + ligne.compte.nom + ' » (' + transactions.length + ')';
    const tbody = $('#table-transactions tbody');
    tbody.replaceChildren();

    if (transactions.length === 0) {
        ligneVide(tbody, 5, 'Aucune opération sur ce compte.');
    }

    for (const t of transactions) {
        const tr = document.createElement('tr');
        const estRevenu = t.type === 'REVENU';
        tr.appendChild(cellule(dateFr(t.date)));
        const libelle = cellule(t.nom);
        if (t.description) {
            libelle.title = t.description;
        }
        tr.appendChild(libelle);
        tr.appendChild(cellule(estRevenu ? 'Revenu' : 'Dépense'));
        tr.appendChild(cellule((estRevenu ? '+ ' : '- ') + montant(t.montant, code), 'nombre ' + (estRevenu ? 'revenu' : 'depense')));
        const actions = document.createElement('td');
        actions.className = 'nombre';
        actions.appendChild(bouton('Supprimer', 'secondary outline', () => supprimerTransaction(t)));
        tr.appendChild(actions);
        tbody.appendChild(tr);
    }
    $('#bloc-transactions').hidden = false;
}

async function supprimerTransaction(t) {
    if (!confirm('Supprimer l\'opération « ' + t.nom + ' » ?')) {
        return;
    }
    const ok = await executer(() => api('DELETE', '/api/transactions/' + t.idTransaction), 'Opération supprimée.');
    if (ok !== undefined) {
        await chargerComptes();
    }
}

async function supprimerCompte(c) {
    if (!confirm('Supprimer le compte « ' + c.nom + ' » ?')) {
        return;
    }
    const ok = await executer(() => api('DELETE', '/api/comptes/' + c.idCompte), 'Compte supprimé.');
    if (ok !== undefined) {
        await chargerComptes();
    }
}

function ajouterLigneVentilation() {
    const ligne = document.createElement('div');
    ligne.className = 'ligne-ventilation';
    const select = document.createElement('select');
    remplirSelect(select, etat.categories, (c) => c.idCategorie, (c) => c.nom);
    const saisie = document.createElement('input');
    saisie.type = 'number';
    saisie.min = '0.01';
    saisie.step = '0.01';
    saisie.placeholder = 'Montant';
    saisie.required = true;
    ligne.appendChild(select);
    ligne.appendChild(saisie);
    ligne.appendChild(bouton('Retirer', 'secondary outline', () => ligne.remove()));
    $('#lignes-ventilation').appendChild(ligne);
}

function majTypeSaisie() {
    const estRevenu = $('#form-saisie').type.value === 'REVENU';
    $('#bloc-source').hidden = !estRevenu;
    $('#bloc-ventilation').hidden = estRevenu;
    $('#lignes-ventilation').querySelectorAll('input').forEach((i) => { i.required = !estRevenu; });
}

async function enregistrerSaisie(evenement) {
    evenement.preventDefault();
    const f = evenement.target;
    const corps = {
        idCompte: Number(f.idCompte.value),
        nom: f.nom.value.trim(),
        description: f.description.value.trim() || null,
        montant: Number(f.montant.value),
        date: f.date.value
    };

    let url;
    if (f.type.value === 'REVENU') {
        url = '/api/revenus';
        corps.idSource = Number(f.idSource.value);
    } else {
        url = '/api/depenses';
        corps.ventilations = [...$('#lignes-ventilation').children].map((ligne) => ({
            idCategorie: Number(ligne.querySelector('select').value),
            montant: Number(ligne.querySelector('input').value)
        }));
    }

    const resultat = await executer(() => api('POST', url, corps));
    if (resultat) {
        afficherMessage('Opération enregistrée. Nouveau solde : ' + montant(resultat.solde, devisesDuCompte(corps.idCompte)), 'succes');
        f.nom.value = '';
        f.description.value = '';
        f.montant.value = '';
        $('#lignes-ventilation').replaceChildren();
        etat.compteOuvert = corps.idCompte;
        await chargerComptes();
    }
}

function devisesDuCompte(idCompte) {
    const ligne = etat.comptes.find((l) => l.compte.idCompte === idCompte);
    return ligne ? codeDevise(ligne.compte.idDevise) : 'EUR';
}

async function creerCompte(evenement) {
    evenement.preventDefault();
    const f = evenement.target;
    const corps = {
        nom: f.nom.value.trim(),
        type: f.type.value,
        montantInitial: Number(f.montantInitial.value),
        idDevise: Number(f.idDevise.value)
    };
    const ok = await executer(() => api('POST', '/api/comptes', corps), 'Compte créé.');
    if (ok !== undefined) {
        f.reset();
        f.closest('details').open = false;
        await chargerComptes();
    }
}

async function chargerTableauBord() {
    const nbMois = $('#tableau-periode').value;
    const donnees = await executer(() => api('GET', '/api/tableau-de-bord?mois=' + nbMois));
    if (!donnees) {
        return;
    }

    const parMois = new Map();
    let rafraichi = null;
    for (const l of donnees.synthese) {
        const cle = l.mois + '|' + l.devise;
        if (!parMois.has(cle)) {
            parMois.set(cle, { mois: l.mois, devise: l.devise, revenus: 0, depenses: 0 });
        }
        const ligne = parMois.get(cle);
        if (l.type === 'REVENU') {
            ligne.revenus += Number(l.total);
        } else {
            ligne.depenses += Number(l.total);
        }
        if (!rafraichi || l.rafraichiLe > rafraichi) {
            rafraichi = l.rafraichiLe;
        }
    }

    $('#tableau-rafraichi').textContent = rafraichi
        ? 'Données calculées le ' + dateFr(rafraichi) + ' à ' + String(rafraichi).substring(11, 16) + ' (vue matérialisée, rafraîchie par l\'administrateur).'
        : 'Aucune donnée calculée pour cette période.';

    const tbodySynthese = $('#table-synthese tbody');
    tbodySynthese.replaceChildren();
    const lignes = [...parMois.values()].sort((a, b) => b.mois.localeCompare(a.mois) || a.devise.localeCompare(b.devise));
    if (lignes.length === 0) {
        ligneVide(tbodySynthese, 5, 'Aucune opération sur la période.');
    }
    for (const l of lignes) {
        const tr = document.createElement('tr');
        const difference = l.revenus - l.depenses;
        tr.appendChild(cellule(moisFr(l.mois)));
        tr.appendChild(cellule(l.devise));
        tr.appendChild(cellule(montant(l.revenus, l.devise), 'nombre revenu'));
        tr.appendChild(cellule(montant(l.depenses, l.devise), 'nombre depense'));
        tr.appendChild(cellule(montant(difference, l.devise), 'nombre ' + (difference >= 0 ? 'revenu' : 'depense')));
        tbodySynthese.appendChild(tr);
    }

    const tbodyCategories = $('#table-categories tbody');
    tbodyCategories.replaceChildren();
    if (donnees.categories.length === 0) {
        ligneVide(tbodyCategories, 4, 'Aucune dépense classée sur la période.');
    }
    for (const c of donnees.categories) {
        const tr = document.createElement('tr');
        tr.appendChild(cellule(c.categorie));
        tr.appendChild(cellule(String(c.nbDepenses), 'nombre'));
        tr.appendChild(cellule(montant(c.total), 'nombre'));
        const part = document.createElement('td');
        const barre = document.createElement('div');
        barre.className = 'barre';
        barre.style.width = Math.min(Number(c.partPourcent), 100) + '%';
        const pourcentage = Number(c.partPourcent).toLocaleString('fr-FR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + ' %';
        barre.title = pourcentage;
        part.appendChild(barre);
        part.append(pourcentage);
        tr.appendChild(part);
        tbodyCategories.appendChild(tr);
    }
}

async function chargerUtilisateurs() {
    const utilisateurs = await executer(() => api('GET', '/api/admin/utilisateurs'));
    if (!utilisateurs) {
        return;
    }
    const tbody = $('#table-utilisateurs tbody');
    tbody.replaceChildren();
    for (const u of utilisateurs) {
        const tr = document.createElement('tr');
        tr.appendChild(cellule(u.pseudo));
        tr.appendChild(cellule(u.email));
        tr.appendChild(cellule(u.role === 'ADMIN' ? 'Administrateur' : 'Utilisateur'));
        tr.appendChild(cellule(dateFr(u.dateInscription)));
        const actions = document.createElement('td');
        actions.className = 'nombre';
        if (u.idUtilisateur !== etat.session.idUtilisateur) {
            actions.appendChild(bouton('Supprimer', 'secondary outline', () => supprimerUtilisateur(u)));
        }
        tr.appendChild(actions);
        tbody.appendChild(tr);
    }
}

async function creerUtilisateur(evenement) {
    evenement.preventDefault();
    const f = evenement.target;
    const corps = {
        role: f.role.value,
        pseudo: f.pseudo.value.trim(),
        email: f.email.value.trim(),
        motDePasse: f.motDePasse.value
    };
    const ok = await executer(() => api('POST', '/api/admin/utilisateurs', corps), 'Utilisateur créé.');
    if (ok !== undefined) {
        f.reset();
        await chargerUtilisateurs();
    }
}

async function supprimerUtilisateur(u) {
    if (!confirm('Supprimer l\'utilisateur « ' + u.pseudo + ' » ?')) {
        return;
    }
    const ok = await executer(() => api('DELETE', '/api/admin/utilisateurs/' + u.idUtilisateur), 'Utilisateur supprimé.');
    if (ok !== undefined) {
        await chargerUtilisateurs();
    }
}

async function chargerStatistiques() {
    const stats = await executer(() => api('GET', '/api/admin/statistiques'));
    if (!stats) {
        return;
    }
    const tbody = $('#table-statistiques tbody');
    tbody.replaceChildren();
    for (const s of stats) {
        const tr = document.createElement('tr');
        tr.appendChild(cellule(moisFr(s.mois)));
        tr.appendChild(cellule(String(s.utilisateursActifs), 'nombre'));
        tr.appendChild(cellule(String(s.nbTransactions), 'nombre'));
        tr.appendChild(cellule(String(s.nbRevenus), 'nombre'));
        tr.appendChild(cellule(String(s.nbDepenses), 'nombre'));
        tbody.appendChild(tr);
    }
}

async function rafraichirTableauBord() {
    const b = $('#bouton-rafraichir');
    b.setAttribute('aria-busy', 'true');
    await executer(() => api('POST', '/api/admin/rafraichir'), 'Tableau de bord rafraîchi pour tous les utilisateurs.');
    b.removeAttribute('aria-busy');
}

async function chargerCategories() {
    etat.categories = await api('GET', '/api/categories');
    const liste = $('#liste-categories');
    liste.replaceChildren();
    for (const c of etat.categories) {
        const li = document.createElement('li');
        li.textContent = c.nom;
        liste.appendChild(li);
    }
}

async function creerCategorie(evenement) {
    evenement.preventDefault();
    const f = evenement.target;
    const ok = await executer(() => api('POST', '/api/admin/categories', { nom: f.nom.value.trim() }), 'Catégorie ajoutée.');
    if (ok !== undefined) {
        f.reset();
        await chargerCategories();
    }
}

const chargements = {
    'onglet-comptes': () => executer(chargerComptes),
    'onglet-saisie': () => executer(chargerComptes),
    'onglet-tableau': chargerTableauBord,
    'onglet-utilisateurs': chargerUtilisateurs,
    'onglet-statistiques': chargerStatistiques,
    'onglet-categories': () => executer(chargerCategories)
};

async function connecter(evenement) {
    evenement.preventDefault();
    const f = evenement.target;
    const session = await executer(() => api('POST', '/api/connexion', {
        email: f.email.value.trim(),
        motDePasse: f.motDePasse.value
    }));
    if (session) {
        etat.session = session;
        f.reset();
        $('#message').hidden = true;
        await executer(afficherApplication);
    }
}

async function deconnecter() {
    await executer(() => api('POST', '/api/deconnexion'));
    etat.session = null;
    etat.compteOuvert = null;
    afficherConnexion();
}

async function demarrer() {
    activerOnglets($('#ecran-utilisateur'));
    activerOnglets($('#ecran-admin'));

    $('#form-connexion').addEventListener('submit', connecter);
    $('#bouton-deconnexion').addEventListener('click', deconnecter);
    $('#form-saisie').addEventListener('submit', enregistrerSaisie);
    $('#form-saisie').addEventListener('change', (e) => { if (e.target.name === 'type') majTypeSaisie(); });
    $('#bouton-ajout-ventilation').addEventListener('click', ajouterLigneVentilation);
    $('#form-compte').addEventListener('submit', creerCompte);
    $('#tableau-periode').addEventListener('change', chargerTableauBord);
    $('#form-utilisateur').addEventListener('submit', creerUtilisateur);
    $('#bouton-rafraichir').addEventListener('click', rafraichirTableauBord);
    $('#form-categorie').addEventListener('submit', creerCategorie);

    const aujourdhui = new Date();
    $('#saisie-date').value = aujourdhui.getFullYear() + '-' + String(aujourdhui.getMonth() + 1).padStart(2, '0') + '-' + String(aujourdhui.getDate()).padStart(2, '0');

    try {
        etat.session = await api('GET', '/api/session');
    } catch (e) {
        etat.session = null;
    }

    if (etat.session) {
        await executer(afficherApplication);
    } else {
        afficherConnexion();
    }
}

demarrer();